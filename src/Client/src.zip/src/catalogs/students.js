import {
    UserOutlined,
    PhoneOutlined,
    CalendarOutlined,
    MailOutlined,
} from '@ant-design/icons';
import {
    useGetStudentsQuery,
    useGetStudentsPagedQuery,
    useAddStudentMutation,
    useRemoveStudentMutation,
    useGetStudentByIdQuery,
} from '../services/studentsApi.js';
import FullNameFilter from '../components/catalog_provider/filters/FullNameFilter.jsx';

const iconStyle = { marginRight: '5px' };

export const config = {
    detailsLink: 'student',
    properties: {
        family: { type: 'string', required: true },
        name: { type: 'string', required: true },
        patron: { type: 'string', required: true },
        fullName: { type: 'string', required: true },
        birthDate: { type: 'date', required: true },
        sex: { type: 'enum', required: true },
        nationality: { type: 'string', required: true },
        snils: { type: 'snils', required: true },
        address: { type: 'string', required: true },
        phone: { type: 'phone', required: true },
        email: { type: 'email', required: true },
        projects: { type: 'string', required: true },
    },
    fields: [
        {
            info: 'ФИО',
            property: 'family',
            className: 'col-2',
            style: { },
            icon: {
                type: UserOutlined,
                style: {iconStyle},
            },
            filter: {
                enable: false,
                type: () => {},
            },
        },
        {
            info: 'пол',
            property: 'gender',
            className: 'col-2',
            style: { },
            icon: {
                type: () => {},
                style: {iconStyle},
            },
            filter: {
                enable: false,
                type: () => {},
            },
        },
    ],
    catalogData: {
        addNewAsync: useAddStudentMutation,
        removeOneAsync: useRemoveStudentMutation,
        getOneByIdAsync: useGetStudentByIdQuery,
        getAllAsync: useGetStudentsQuery,
        getAllPagedAsync: useGetStudentsPagedQuery,
    },
};