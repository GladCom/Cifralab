import React, { useState, useCallback, useMemo, useEffect } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import cn from 'classnames';

const Item = ({ columns, data, setItem, showDialog, onClick }) => {
    const { id } = data;
    const [hoverOnItem, setHoverOnItem] = useState(false);
    const deleteButtonClss = cn('btn-sm m-2', { 'd-none': !hoverOnItem });
    const containerClss = cn('mb-2', 'border-bottom', { 
        'bg-light': hoverOnItem, 
        'bg-white': !hoverOnItem,
    });

    return (
        <Container
            role="button"
            className={containerClss}
            onMouseEnter={(e) => setHoverOnItem(true)}
            onMouseLeave={(e) => setHoverOnItem(false)}
            onClick={() => onClick(id)}
        >
            <Row>
                {
                    columns.map((c) => {
                        const classes = cn('m-2', c.className);
                        
                        return (
                            <Col className={classes}>
                                <span>{data[c.property]}</span>
                            </Col>
                        );
                    })
                }
                <Col className="auto d-flex justify-content-end">
                    <Button
                        className={deleteButtonClss}
                        variant="outline-danger"
                        onClick={() => {
                            setItem(id);
                            showDialog(true);
                        }}
                    >
                        Удалить
                    </Button>
                </Col>
            </Row>
        </Container>
    );
};

export default Item;