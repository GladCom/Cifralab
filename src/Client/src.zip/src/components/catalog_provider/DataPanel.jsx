import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import _ from 'lodash';
import ListHeader from './ListHeader.jsx';
import Item from './Item.jsx';
import RemoveForm from './forms/RemoveForm.jsx';

const DataPanel = ({ columns, detailsLink, data, removeOneAsync, refetch }) => {
    const [showRemoveForm, setShowRemoveForm] = useState(false);
    const [itemId, setItemId] = useState('');
    const [removeItem, queryState] = removeOneAsync();
    const navigate = useNavigate();

    const openDetailsInfo = useCallback((id) => {
        navigate(`/${detailsLink}/${id}`);
    });
    return (
        <>
            {
                showRemoveForm 
                && <RemoveForm 
                    show={setShowRemoveForm} 
                    validate={() => removeItem(itemId)}
                    queryState={queryState}
                    refetch={refetch}
                />
            }
            <div className="row">
                <ListHeader columns={columns} />
                {data?.map((d) => (
                    <Item
                        columns={columns}
                        data={d}
                        setItem={setItemId}
                        showDialog={setShowRemoveForm}
                        onClick={openDetailsInfo}
                    />
                ))}
            </div>
        </>
    );
};

export default DataPanel;