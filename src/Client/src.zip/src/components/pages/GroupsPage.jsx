import React from 'react';
import Layout from '../shared/Layout';

const GroupsPage = () => {
    return (
        <Layout title="Группы">
            <span>Страница с группами</span>
        </Layout>
    );
};

export default GroupsPage;