import React from 'react';

const RequestPanel = () => {

    return (
        <div className="row">
            Тут должны быть заявки!
        </div>
    );
};

export default RequestPanel;